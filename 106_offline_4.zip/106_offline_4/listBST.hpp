#ifndef LISTBST_H
#define LISTBST_H

#include "BST.hpp"
#include <iostream>
#include <stdexcept>

/**
 * Binary Search Tree implementation using linked list structure
 * 
 * @tparam Key - The type of keys stored in the BST
 * @tparam Value - The type of values associated with keys
 */
template <typename Key, typename Value>
class ListBST : public BST<Key, Value> {
private:
    /**
     * Node class for the binary search tree
     */
    class Node {
    public:
        Key key;
        Value value;
        Node* left;
        Node* right;
        
        Node(Key k, Value v) : key(k), value(v), left(nullptr), right(nullptr) {}
    };
    
    Node* root;
    size_t node_count;
    
    // TODO: Implement private helper functions as needed
    // Start your private helper functions here
    void destructor_helper(Node* root)
    {
        if(root==NULL) return;
        if(root->left!=NULL) {destructor_helper(root->left);}
        if(root->right!=NULL) {destructor_helper(root->right);}
        delete root;
    }


    bool insert_helper(Node*& root, Key key, Value value)
    {
      Node* y=NULL;
      Node* x=root;
      while(x!=NULL)
      {
        y=x;
        if(key<x->key) x=x->left;
        else if(key>x->key) x=x->right;
        else return false;
      }
      Node* new_node= new Node(key, value);
      if(y==NULL) {root=new_node;}
      else if(key>y->key) y->right=new_node;
      else y->left=new_node;
      return true;
    }


    Node* find_parent(Node* root, Node* child)
    {  
      if(root==NULL || child->key==root->key) return NULL;
      else if((root->left!=NULL && root->left->key==child->key) || (root->right!=NULL && root->right->key==child->key)) return root;
      else if(root->key>child->key) return find_parent(root->left, child);
      else return find_parent(root->right, child);
    }


    Node* find_successor(Node* root, Node* node)
    {  
      if(node->right!=NULL) return find_min_helper2(node->right);
      Node* temp=node;
      Node* y=find_parent(root, node);
      while(y!=NULL && temp==y->right)
      {
        temp=y;
        y=find_parent(root, y);
      }
      return y;
    }


    bool remove_helper(Node* root, Key key)
    {
      Node* node_remove=find_helper2(root, key);
      if(node_remove==NULL) return false;
      Node* node_remove_parent=find_parent(root, node_remove);
      if(node_remove_parent==NULL && node_remove->left==NULL && node_remove->right==NULL) {this->root=nullptr; delete node_remove; return true;}
      if(node_remove_parent==NULL && node_remove->left!=NULL && node_remove->right==NULL) {this->root=this->root->left; delete node_remove; return true;}
      if(node_remove_parent==NULL && node_remove->left==NULL && node_remove->right!=NULL) {this->root=this->root->right; delete node_remove; return true;}
      if(node_remove_parent==NULL && node_remove->left!=NULL && node_remove->right!=NULL) 
      {Node* node_remove_successor=find_successor(root, node_remove);
        Key node_remove_key=node_remove_successor->key;
        Value node_remove_value=node_remove_successor->value;
        remove_helper(root, node_remove_successor->key);
        node_remove->key=node_remove_key;
        node_remove->value=node_remove_value;
        return true;}
      int number_of_child;
      if(node_remove->left!=NULL && node_remove->right!=NULL) number_of_child=2;
      else if((node_remove->left==NULL && node_remove->right!=NULL) || (node_remove->left!=NULL && node_remove->right==NULL)) number_of_child=1;
      else number_of_child=0;
      if(number_of_child==0)
      {
        if(node_remove_parent->left==node_remove) node_remove_parent->left=NULL;
        else node_remove_parent->right=NULL;
        delete node_remove;
      }
      if(number_of_child==1)
      {
        Node* node_remove_child;
        if(node_remove->left==NULL) node_remove_child=node_remove->right;
        else node_remove_child=node_remove->left;
        if(node_remove==node_remove_parent->left) node_remove_parent->left=node_remove_child;
        else node_remove_parent->right=node_remove_child;
        delete node_remove;
      }
      if(number_of_child==2)
      {
        Node* node_remove_successor=find_successor(root, node_remove);
        Key node_remove_key=node_remove_successor->key;
        Value node_remove_value=node_remove_successor->value;
        remove_helper(root, node_remove_successor->key);
        node_remove->key=node_remove_key;
        node_remove->value=node_remove_value;
      }
      return true;
    }


    const Node* find_helper1(const Node* root, Key key) const
    {  
      if(root==NULL || root->key==key) return root;
      if(root->key>key) return find_helper1(root->left, key);
      else return find_helper1(root->right, key);
    }

    Node* find_helper2(Node* root, Key key) 
    {  
      if(root==NULL || root->key==key) return root;
      if(root->key>key) return find_helper2(root->left, key);
      else return find_helper2(root->right, key);
    }


    Value get_helper(const Node* root, Key key) const
    {
      if(root==NULL) throw std::runtime_error("Key not found.");  
      if(root->key==key) return root->value;
      if(root->key>key) return get_helper(root->left, key);
      else return get_helper(root->right, key);
    }


    void update_helper(Node* root, Key key, Value value)
    {
      if(root==NULL) throw std::runtime_error("Key not found.");  
      if(root->key==key) {root->value=value; return;}
      if(root->key>key) update_helper(root->left, key, value);
      else update_helper(root->right, key, value);
    }

    Key find_min_helper(const Node* root) const
    {
      if(root==NULL)  throw std::runtime_error("BST is empty.");
      while(root->left!=NULL)
      {
        root=root->left;
      }
      return root->key;
    }


    Node* find_min_helper2(Node* root)
    {
      if(root==NULL)  throw std::runtime_error("BST is empty.");
      while(root->left!=NULL)
      {
        root=root->left;
      }
      return root;
    }


    Key find_max_helper(const Node* root) const
    {
      if(root==NULL)  throw std::runtime_error("BST is empty.");
      while(root->right!=NULL)
      {
        root=root->right;
      }
      return root->key;
    }

    std::string print_key(const int key) const
    {
      return std::to_string(key);
    }

    std::string print_key(const std::string key) const
    {
      return key;
    }

    std::string print_value(const int value) const
    {
      return std::to_string(value);
    }

    std::string print_value(const std::string value) const
    {
      return value;
    }


    std::string print_helper(const Node* root, char traversal_type) const
    {
        std::string bst="";
        if(traversal_type=='D'|| traversal_type=='d')
        {
          if(root==NULL) {return bst;}
          if(root->left!=NULL && root->right!=NULL) {bst+="("+print_key(root->key)+":"+print_value(root->value)+" "; bst+=print_helper(root->left, 'D'); bst+=print_helper(root->right, 'D'); bst+=") ";}
          if(root->left!=NULL && root->right==NULL) {bst+="("+print_key(root->key)+":"+print_value(root->value)+" "; bst+=print_helper(root->left, 'D'); bst+="()";  bst+=") ";}
          if(root->left==NULL && root->right!=NULL) {bst+="("+print_key(root->key)+":"+print_value(root->value)+" "; bst+="()"; bst+=print_helper(root->right, 'D'); bst+=") ";}
          if(root->left==NULL && root->right==NULL)  {bst+="("+print_key(root->key)+":"+print_value(root->value)+" )";}
        }

        else if(traversal_type=='I' || traversal_type=='i')
        {
          if(root==NULL) {return bst;}
          if(root->left!=NULL) bst+=print_helper(root->left, 'I');
          bst+="("+print_key(root->key)+":"+print_value(root->value)+")";
          if(root->right!=NULL) bst+=print_helper(root->right, 'I');
        }

        else if(traversal_type=='P' || traversal_type=='p')
        {
          if(root==NULL) {return bst;}
          bst+="("+print_key(root->key)+":"+print_value(root->value)+")";
          if(root->left!=NULL) bst+=print_helper(root->left, 'P');
          if(root->right!=NULL) bst+=print_helper(root->right, 'P');
        }

        else if(traversal_type=='O' || traversal_type=='o')
        {
          if(root==NULL) {return bst;}
          if(root->left!=NULL) bst+=print_helper(root->left, 'O');
          if(root->right!=NULL) bst+=print_helper(root->right, 'o');
          bst+="("+print_key(root->key)+":"+print_value(root->value)+")";
        }

        else
        {
          throw std::invalid_argument("Invalid traversal order.");
        }
        return bst;
    }
    
    // End your private helper functions here






public:
    /**
     * Constructor
     */
    ListBST() : root(nullptr), node_count(0) {}
    
    /**
     * Destructor
     */
    ~ListBST() {
        // TODO: Implement destructor to free memory
        this->destructor_helper(this->root);
    }
    
    /**
     * Insert a key-value pair into the BST
     */
    bool insert(Key key, Value value) override {
        // TODO: Implement insertion logic
        bool successfully_inserted= this->insert_helper(this->root, key, value);
        if(successfully_inserted) this->node_count++; 
        return successfully_inserted;
    }
    
    /**
     * Remove a key-value pair from the BST
     */
    bool remove(Key key) override {
        // TODO: Implement removal logic
        bool successfully_removed= this->remove_helper(this->root, key);
        if(successfully_removed)  this->node_count--;
        return successfully_removed;
    }
    
    /**
     * Find if a key exists in the BST
     */
    bool find(Key key) const override {
        // TODO: Implement find logic
        const Node* node_found=find_helper1(this->root, key);
        if(node_found!=nullptr) return true;
        else return false;
    }

    /**
     * Find a value associated with a given key
     */
    Value get(Key key) const override {
        // TODO: Implement get logic
        try
        {
          return get_helper(this->root, key);
        }
        catch(const std::exception& e)
        {
            std::cerr << e.what()<<" Returning a random value: ";
            Value v;
            return v;
        }
    }

    /**
     * Update the value associated with a given key
     */
    void update(Key key, Value value) override {
        // TODO: Implement update logic
        try
        {
            update_helper(this->root, key, value);
        }
        catch(const std::exception& e)
        {
            std::cerr << e.what() << '\n';
        }
    }

    /**
     * Clear all elements from the BST
     */
    void clear() override {
        // TODO: Implement clear logic
        this->destructor_helper(this->root);
        this->root=nullptr;
        this->node_count=0;
    }
    
    /**
     * Get the number of keys in the BST
     */
    size_t size() const override {
        // TODO: Implement size logic
        return this->node_count;
    }
    
    /**
     * Check if the BST is empty
     */
    bool empty() const override {
        // TODO: Implement empty check logic
        return this->node_count==0;
    }
    
    /**
     * Find the minimum key in the BST
     */
    Key find_min() const override {
        // TODO: Implement find_min logic
        try
        {
            return find_min_helper(this->root);
        }
        catch(const std::exception& e)
        {
            std::cerr << e.what()<<" Returning a random key: ";
            Key k;
            return k;
        }
    }
    
    /**
     * Find the maximum key in the BST
     */
    Key find_max() const override {
        // TODO: Implement find_max logic
        try
        {
            return find_max_helper(this->root);
        }
        catch(const std::exception& e)
        {
            std::cerr << e.what()<<" Returning a random key: ";
            Key k;
            return k;
        }
    }

    /**
     * Print the BST using specified traversal method
     */
    void print(char traversal_type = 'D') const override {
        // TODO: Implement print logic
        try
        {
          std::cout<<print_helper(this->root, traversal_type);
        }
        catch(const std::exception& e)
        {
            std::cerr << e.what() << '\n';
        }
    }
    
};

#endif // LISTBST_H




