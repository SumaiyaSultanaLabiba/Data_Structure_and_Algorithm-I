#include <iostream>
#include <fstream>
#include "listBST.hpp"

using namespace std;

int main(int argc, char **argv) {
    if (argc != 2) {
        cerr << "Usage: filename" << "\n";
        return 1;
    }
    ifstream in_file(argv[1]);
    if (!in_file) {
        cerr << "Unable to open file\n";
        return 2;
    }
    char c, str[5];
    int val;
    BST<int, int> *bst = new ListBST<int, int>();
    if (!bst) {
        cerr << "Memory allocation failed\n";
        return 3;
    }
    while (in_file >> c) {
        // TODO: Implement the logic to read commands from the file and output accordingly
        // After every insertion and removal, print the BST in nested parentheses format
        // Handle exceptions where necessary and print appropriate error messages

        // Start your code here
        if(c=='I')
        {
            int key;
            in_file>>key;
            if(bst->insert(key, key))
            {
            cout<<"Key "<<key<<" inserted into BST, ";
            }
            else
            {
                cout<<"Insertion failed! Key "<<key<<" already exists in BST, ";
            }
            cout<<"BST (Default): "; bst->print(); cout<<endl;
        }

        else if(c=='T')
        {
            string type;
            in_file>>type;
            if(type=="In") {cout<<"BST (In-order): "; bst->print('I'); cout<<endl;}
            if(type=="Pre") {cout<<"BST (Pre-order): "; bst->print('P'); cout<<endl;}
            if(type=="Post") {cout<<"BST (Post-order): "; bst->print('O'); cout<<endl;}
        }

        else if(c=='D')
        {
            int key;
            in_file>>key;
            if(bst->remove(key))
            {
            cout<<"Key "<<key<<" removed from BST, ";
            }
            else
            {
                cout<<"Removal failed! Key "<<key<<" not found in BST, ";
            }
            cout<<"BST (Default): "; bst->print(); cout<<endl;
        }

        else if(c=='S')
        {
            cout<<"Size: "<<bst->size()<<endl;
        }

        else if(c=='F')
        {
            int key;
            in_file>>key;
            if(bst->find(key)) cout<<"Key "<<key<<" found in BST."<<endl;
            else cout<<"Key "<<key<<" not found in BST."<<endl;
        }

        else if(c=='M')
        {
            std::string type;
            in_file>>type;
            if(type=="Max") cout<<"Maximum value: "<<bst->find_max()<<endl;
            if(type=="Min") cout<<"Minimum value: "<<bst->find_min()<<endl;
        }

        else if(c=='E')
        {
            if(bst->empty()) cout<<"Empty"<<endl;
            else cout<<"Not empty"<<endl;
        }
        
        // End your code here
    }
    in_file.close();
    delete bst;
    return 0;
}

//    g++ -std=c++11 task1.cpp -o task1
//    ./task1 in_task1.txt > myout_task1.txt
