#include "queue.h"
#include <iostream>
using namespace std;


// Constructor implementation
ArrayQueue::ArrayQueue(int initial_capacity)
{
    // TODO: Initialize data members (data, capacity, front_idx, rear_idx)
    // TODO: Allocate memory for the array with the specified initial capacity
    this->capacity=initial_capacity;
    this->data=new int[this->capacity];
    this->front_idx=-1;
    this->rear_idx=-1;
}



// Destructor implementation
ArrayQueue::~ArrayQueue()
{
    // TODO: Free the dynamically allocated memory for the array
    delete[] this->data;
}



// Enqueue implementation (add an item to the rear of the queue)
void ArrayQueue::enqueue(int item)
{
    // TODO: Check if the array is full
    // TODO: If full, resize the array to double its current capacity
    if(this->size()==this->capacity)
    {
        this->resize(this->capacity*2);
    }
    // TODO: Add the new element to the rear of the queue
    this->rear_idx=(this->rear_idx+1)%this->capacity;
    this->data[this->rear_idx]= item;
    //Only for the first element, the front_idx must be updated
    if(this->front_idx==-1)
    {
        this->front_idx=0;
    }
}



// Dequeue implementation (remove an item from the front of the queue)
int ArrayQueue::dequeue()
{
    // TODO: Check if the queue is empty, display error message if it is
    if(this->empty())
    {
        cout<<"Cannot dequeue from an empty queue, returning -1"<<endl;
        return -1;
    }
    // TODO: Decrement current_size and return the element at the front of the queue
    // TODO: Update front index
    int dequeued_element=this->data[this->front_idx];
    //Only for the last element, the rear_idx must be updated
    if(this->size()==1)
    {
       this->front_idx=-1;
       this->rear_idx=-1;
    }
    else
    {
       this->front_idx=(this->front_idx+1)%this->capacity;
    }
    //Shrinking (if needed) the queue after dequeue operation
    if((this->size()<=this->capacity/4) && (this->capacity/2)>=2)
    {
        this->resize(this->capacity/2);
    }
    // TODO: Return the dequeued element
    return dequeued_element;
}



// Clear implementation
void ArrayQueue::clear()
{
    // TODO: Reset the queue to be empty (reset capacity, front_idx, rear_idx, data)
    delete[] this->data;
    int* new_data= new int[2];
    this->data=new_data;
    this->capacity=2;
    this->front_idx=-1;
    this->rear_idx=-1;
}



// Size implementation
int ArrayQueue::size() const
{
    // TODO: Return the number of elements currently in the queue
    int current_size=0;
    if(this->front_idx==-1 && this->rear_idx==-1)
    {
        return current_size;
    }
    int start_count= this->front_idx;
    int stop_count= this->rear_idx;
    while(start_count!=stop_count)
    {
        current_size++;
        start_count=(start_count+1)% this->capacity;
    }
    current_size++;
    return current_size;
}



// Front implementation
int ArrayQueue::front() const
{
    // TODO: Check if the queue is empty, display error message if it is
    if(this->empty())
    {
        cout<<"Empty queue has no front element, returning -1"<<endl;
        return -1;
    }
    // TODO: Return the element at the front of the queue without removing it
    return this->data[this->front_idx];
}



// Back implementation (get the element at the back of the queue)
int ArrayQueue::back() const
{
    // TODO: Check if the queue is empty, display error message if it is
    if(this->empty())
    {
        cout<<"Empty queue has no back element, returning -1"<<endl;
        return -1;
    }
    // TODO: Return the element at the back of the queue without removing it
    return this->data[this->rear_idx];
}



// Empty implementation
bool ArrayQueue::empty() const
{
    // TODO: Return whether the queue is empty (current_size == 0)
    if(this->size()==0) return true;
    return false;
}



// Print implementation
string ArrayQueue::toString() const
{
    // TODO: Convert queue to a string representation in the format: <elem1, elem2, ..., elemN|
    string output;
    output=output+"<";
    int index=this->front_idx;
    for(int i=0; i<this->size(); i++)
    {
        char current_element[5];
        sprintf(current_element, "%d", this->data[index]);
        index=(index+1)%this->capacity;
        output=output+(string)(current_element);
        if(i<this->size()-1)
        {
            output=output+", ";
        }
    }
    output=output+"|";
    return output;
}



// Resize implementation
void ArrayQueue::resize(int new_capacity)
{
    // TODO: Create a new array with the new capacity
    // TODO: Update the data pointer and capacity
    int current_size=this->size();
    int old_capacity=this->capacity;
    int* old_data=this->data;
    this->capacity=new_capacity;
    this->data=new int[new_capacity];
    // TODO: Copy elements from the old array to the new array
    for(int i=0; i<current_size; i++)
    {
        this->data[i]=old_data[this->front_idx];
        this->front_idx=(this->front_idx+1)%old_capacity;
    }
    // TODO: Delete the old array
    delete[] old_data;
    // TODO: Update front and rear indices
    this->front_idx=0;
    this->rear_idx=current_size-1;
}



int ArrayQueue::getCapacity() const
{
    // TODO: Return the current capacity of the queue
    return this->capacity;
}

