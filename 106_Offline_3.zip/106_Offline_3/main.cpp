#include <iostream>
#include <vector>
#include "queue.h"
using namespace std;

/********************************* RANDOM ************************************/
//  g++ -std=c++11 main.cpp arrayqueue.cpp listqueue.cpp -o main
//  ./main
#define LCG_MULTIPLIER (1103515245)
#define LCG_INCREMENT (12345)
#define LCG_MODULUS ((unsigned)~0 >> 1)
static unsigned int lcg_seed = 1;
void custom_srand(unsigned int seed)
{
    lcg_seed = seed;
}
int custom_rand()
{
    lcg_seed = (LCG_MULTIPLIER * lcg_seed + LCG_INCREMENT) % (LCG_MODULUS + 1);
    return lcg_seed;
}
int randomQueue(int seed = -1)
{
    static bool initialized = false;
    if (seed != -1 && !initialized)
    {
        custom_srand(seed);
        initialized = true;
        return -1;
    }
    cout << "randomQueue() called" << endl;
    return (custom_rand() % 2) + 1;
}
/*****************************************************************************/
   

int main()
{
    freopen("test_input_1.txt", "r", stdin); // Test Case 1
    //freopen("test_input_2.txt", "r", stdin); // Test Case 2
    freopen("output.txt", "w", stdout);


    // Initialize the random generator with a fixed seed
    // You should set the seed only once at the beginning of your program
    // NOTE: Do not modify the following lines.
    randomQueue(42);

    Queue *Q1 = new ListQueue();
    Queue *Q2 = new ListQueue();
    Queue *Q = new ArrayQueue();

    int N;
    cin >> N;
    int timestamp_array[N+1]; 
    int timestamp_array_last_index=0;
    
    for (int i = 1; i <= N; i++)
    {
        // TODO: Edit here to add your own logic
        int operation_type=0;
        cin>>operation_type;


        //Arrival (Input format: 1 id timestamp)
        if(operation_type==1)
        {
          int id, timestamp;
          cin>>id;
          cin>>timestamp;  
          cout<<"Operation "<<i<<" (Arrival "<<id<<" "<<timestamp<<"): "; 
          timestamp_array[timestamp]=id;
          timestamp_array_last_index++;

          if(Q1->empty() && Q2->empty() && Q->empty())
          {
            int selected_queue=randomQueue();
            if(selected_queue==1) Q1->enqueue(id);
            if(selected_queue==2) Q2->enqueue(id);
          }

          else if(Q1->empty() && !Q2->empty() && Q->empty())
          {
            cout<<endl;
            Q1->enqueue(id);
          }

          else if(!Q1->empty() && Q2->empty() && Q->empty())
          {
            cout<<endl;
            Q2->enqueue(id);
          }

          else if(!Q1->empty() && !Q2->empty() && Q->empty())
          {
            cout<<endl;
            int last_id_Q1=Q1->back();
            int last_id_index_Q1;
            int last_id_Q2=Q2->back();
            int last_id_index_Q2;

            for(int k=1; k<N+1; k++)
            {
                if(timestamp_array[k]==last_id_Q1)
                {
                    last_id_index_Q1=k;
                    break;
                }
            }

            for(int k=1; k<N+1; k++)
            {
                if(timestamp_array[k]==last_id_Q2)
                {
                    last_id_index_Q2=k;
                    break;
                }
            }
            if(last_id_index_Q1<last_id_index_Q2)
            {
                Q1->enqueue(id);
            }
            if(last_id_index_Q2<last_id_index_Q1)
            {
                Q2->enqueue(id);
            }
          }

          else if(!Q->empty())
          {
            cout<<endl;
            Q->enqueue(id);
          }

          cout<<"Q1: "<<Q1->toString()<<endl;
          cout<<"Q2: "<<Q2->toString()<<endl;
          cout<<"Q: "<<Q->toString()<<endl;
        }
        


        //Leave (Input format: 2 id timestamp)
        else if(operation_type==2)
        {
          int id, timestamp;
          cin>>id;
          cin>>timestamp;  
          cout<<"Operation "<<i<<" (Leave "<<id<<" "<<timestamp<<"): "<<endl; 
          timestamp_array[timestamp]=id;
          timestamp_array_last_index++;
          if(Q->empty())
          {
            int Q1_size=Q1->size();
            for(int k=1; k<=Q1_size; k++)
            {
                if(Q1->front()==id) Q1->dequeue();
                else Q1->enqueue(Q1->dequeue());
            }

            int Q2_size=Q2->size();
            for(int k=1; k<=Q2_size; k++)
            {
                if(Q2->front()==id) Q2->dequeue();
                else Q2->enqueue(Q2->dequeue());
            }
          }
          else
          {
            int Q_size=Q->size();
            for(int k=1; k<=Q_size; k++)
            {
                if(Q->front()==id) Q->dequeue();
                else Q->enqueue(Q->dequeue());
            }
          }
          cout<<"Q1: "<<Q1->toString()<<endl;
          cout<<"Q2: "<<Q2->toString()<<endl;
          cout<<"Q: "<<Q->toString()<<endl;  
        }



        //Merge (Input format: 3)
        else if(operation_type==3)
        {
          cout<<"Operation "<<i<<" (Merge): "<<endl; 

          if(Q1->empty() && Q2->empty()) ;

          else if(!Q1->empty() && Q2->empty())
          {
            int Q1_size=Q1->size();
            for(int k=1; k<=Q1_size; k++)
            {
                Q->enqueue(Q1->dequeue());
            }
          }

          else if(Q1->empty() && !Q2->empty())
          {
            int Q2_size=Q2->size();
            for(int k=1; k<=Q2_size; k++)
            {
                Q->enqueue(Q2->dequeue());
            }
          }

          else
          {
            while(!Q1->empty() && !Q2->empty())
            {
                int front_Q1=Q1->front();
                int front_Q2=Q2->front();
                int front_Q1_timestamp=0;
                int front_Q2_timestamp=0;

                for(int k=1; k<=timestamp_array_last_index; k++)
                {
                    if(timestamp_array[k]==front_Q1)
                    {
                       front_Q1_timestamp=k;
                       break;
                    }
                }

                for(int k=1; k<=timestamp_array_last_index; k++)
                {
                    if(timestamp_array[k]==front_Q2)
                    {
                       front_Q2_timestamp=k;
                       break;
                    }
                }

                if(front_Q1_timestamp<front_Q2_timestamp) {Q->enqueue(front_Q1); Q1->dequeue();}
                if(front_Q2_timestamp<front_Q1_timestamp) {Q->enqueue(front_Q2); Q2->dequeue();}
            }

             if(!Q1->empty() && Q2->empty())
             {
               int Q1_size=Q1->size();
               for(int k=1; k<=Q1_size; k++)
               {
                  Q->enqueue(Q1->dequeue());
               }
             }

             else if(Q1->empty() && !Q2->empty())
             {
               int Q2_size=Q2->size();
               for(int k=1; k<=Q2_size; k++)
               {
                 Q->enqueue(Q2->dequeue());
               }
             }

             else ;
          }

          Q1->clear();
          Q2->clear();
          cout<<"Q1: "<<Q1->toString()<<endl;
          cout<<"Q2: "<<Q2->toString()<<endl;
          cout<<"Q: "<<Q->toString()<<endl;
        }



        //Split (Input format: 4)
        else if(operation_type==4)
        {
          cout<<"Operation "<<i<<" (Split): "<<endl; 
          int Q_size=Q->size();
          for(int k=1; k<=Q_size; k++)
          {
            if(k%2!=0) {Q1->enqueue(Q->front()); Q->dequeue();}
            if(k%2==0) {Q2->enqueue(Q->front()); Q->dequeue();}
          }
          Q->clear(); 
          cout<<"Q1: "<<Q1->toString()<<endl;
          cout<<"Q2: "<<Q2->toString()<<endl;
          cout<<"Q: "<<Q->toString()<<endl;
        }
        


        //Departure (Input format: 5)
        else if(operation_type==5)
        {
          cout<<"Operation "<<i<<" (Departure): "; 
          if(!Q->empty() && Q1->empty() && Q2->empty())
          {
            cout<<endl;
            Q->dequeue();
          }  

          else if(Q->empty() && !Q1->empty() && Q2->empty())
          {
            cout<<endl;
            Q1->dequeue();
          }

          else if(Q->empty() && Q1->empty() && !Q2->empty())
          {
            cout<<endl;
            Q2->dequeue();
          }
          else if(Q->empty() && !Q1->empty() && !Q2->empty())
          {
            int selected_queue=randomQueue();
            if(selected_queue==1) Q1->dequeue();
            if(selected_queue==2) Q2->dequeue();
          }

          cout<<"Q1: "<<Q1->toString()<<endl;
          cout<<"Q2: "<<Q2->toString()<<endl;
          cout<<"Q: "<<Q->toString()<<endl;
        }


        // After each operation, we will check the queue's size and capacity
        // NOTE: Do not modify the following lines.
        int capacity = ((ArrayQueue *)Q)->getCapacity();
        if ((Q->size() < capacity / 4 && capacity > 2))
        {
            cout << "Error: Queue size is less than 25% of its capacity." << endl;
        }
        else if (capacity < 2)
        {
            cout << "Error: Queue capacity is less than 2." << endl;
        }
    }

    return 0;
}