#include "queue.h"
#include <iostream>
using namespace std;



// Constructor implementation
ListQueue::ListQueue()
{
    // TODO: Initialize front_node and rear_node
    // TODO: Initialize current_size to 0
    this->front_node=nullptr;
    this->rear_node=nullptr;
    this->current_size=0;
}



// Destructor implementation
ListQueue::~ListQueue()
{
    // TODO: Deallocate all nodes in the linked list
    // TODO: Consider using the clear() method
    this->clear();
}



// Enqueue implementation (add an item at the rear of the queue)
void ListQueue::enqueue(int item)
{
    // TODO: Create a new node with the given item
    // TODO: Link the new node to the rear
    // TODO: Update the rear_node
    // TODO: Increment the current size
    Node* new_node=new Node(item, nullptr);
    if(this->current_size==0) 
    {
        this->rear_node=new_node;
        this->front_node=new_node;
    }
    else
    {
        this->rear_node->next=new_node;
        this->rear_node=this->rear_node->next;
    }
    this->current_size++;
}



// Dequeue implementation (remove an item from the front of the queue)
int ListQueue::dequeue()
{
    // TODO: Check if the queue is empty, display error message if it is
    // TODO: Store the data from the front node
    // TODO: Update the front pointer to the next node
    // TODO: Update the rear pointer if the queue becomes empty
    // TODO: Delete the old front node
    // TODO: Decrement current_size
    // TODO: Return the stored data
    if(this->empty())
    {
        cout<<"Cannot dequeue from an empty queue, returning -1."<<endl;
        return -1;
    }
    int dequeued_element=this->front_node->data;
    Node* current=this->front_node;
    this->front_node=this->front_node->next;
    if(this->current_size==1)
    {
        this->front_node=nullptr;
        this->rear_node=nullptr;
    }
    delete current;
    this->current_size--;
    return dequeued_element;
}



// Clear implementation (delete all elements)
void ListQueue::clear()
{
    // TODO: Traverse the linked list and delete each node
    // TODO: Reset front and rear pointer
    // TODO: Reset current_size to 0
    for(int i=0; i<this->current_size; i++)
    {
        this->dequeue();
    }
    this->front_node=nullptr;
    this->rear_node=nullptr;
    this->current_size=0;
}



// Size implementation (return the current number of elements)
int ListQueue::size() const
{
    // TODO: Return the current size (current_size)
    return this->current_size;
}



// Front implementation (get the element at the front of the queue)
int ListQueue::front() const
{
    // TODO: Check if the queue is empty, display error message if it is
    // TODO: Return the data from the front node without removing it
    if(this->empty())
    {
        cout<<"Empty queue has no front element, returning -1."<<endl;
        return -1;
    }
    return this->front_node->data;
}



// Back implementation (get the element at the back of the queue)
int ListQueue::back() const
{
    // TODO: Check if the queue is empty, display error message if it is
    // TODO: Return the data from the back node without removing it
    if(this->empty())
    {
        cout<<"Empty queue has no back element, returning -1."<<endl;
        return -1;
    }
    return this->rear_node->data;
}



// Empty implementation (check if the queue is empty)
bool ListQueue::empty() const
{
    // TODO: Return whether front is nullptr
    if(this->front_node==nullptr) return true;
    return false;
}



// Print implementation (print elements from front to rear)
string ListQueue::toString() const
{
    // TODO: Convert queue to a string representation in the format: <elem1, elem2, ..., elemN|
    // TODO: Traverse the linked list from front
    string output;
    output=output+"<";
    Node* current=this->front_node;
    for(int i=0; i<this->current_size; i++)
    {
        char current_element[5];
        sprintf(current_element, "%d", current->data);
        output=output+string(current_element);
        current=current->next;
        if(i<this->current_size-1)
        {
            output=output+", ";
        }
    }
    output=output+"|";
    return output;
}

