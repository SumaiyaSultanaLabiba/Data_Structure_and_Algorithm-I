#include<iostream>
#include<fstream>
#include<cstdio>
#include<queue>
#include<ctime>
#include "heap.h" //You need to implement this.
using namespace std;


int HEAPSORT(int array[], int size, int k)
{
  if(k>size) return -1;  
  int kth_smallest_element;
  Heap h(size);
  for(int i=0; i<size; i++)
  {
    h.insert(array[i]);
  }
  for(int i=0; i<size; i++)
  {
    array[i]=h.deleteKey();
  }
  kth_smallest_element=array[k-1];
  return kth_smallest_element;
}

int main()
{
    int N;
    cin>>N;
    int random_set[N]={0};
    for(int i=0; i<N; i++)
    {
        cin>>random_set[i];
        if(i>=2)
        {
            int k=1;
            int first_largest_element=HEAPSORT(random_set, N, k);
            k=2;
            int second_largest_element=HEAPSORT(random_set, N, k);
            k=3;
            int third_largest_element=HEAPSORT(random_set, N, k);
            cout<<"Printing product of largest three numbers "<<(first_largest_element*second_largest_element*third_largest_element)<<endl;
        }
        else cout<<-1<<endl;
    }
    return 0;
}