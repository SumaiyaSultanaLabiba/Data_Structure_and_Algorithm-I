#include<iostream>
#include<fstream>
#include<cstdio>
#include<queue>
#include<ctime>
#include "heap.h" //You need to implement this.
using namespace std;


int HEAPSORT(int array[], int size, int k)
{
  if(k>size) return -1;  
  int kth_smallest_element;
  Heap h(size);
  for(int i=0; i<size; i++)
  {
    h.insert(array[i]);
  }
  for(int i=0; i<size; i++)
  {
    array[i]=h.deleteKey();
  }
  kth_smallest_element=array[k-1];
  return kth_smallest_element;
}

int main()
{
    Heap h(10);
    string myText;
    ifstream MyReadFile("my.txt");
    while (getline (MyReadFile, myText))
    h.insert(atoi(myText.c_str()));
    MyReadFile.close();
    h.print();
    int random_set[10]={13, 15, 20, 10, 12, 5, 9, 6, 8, 7};
    int k=11;
    cout<<HEAPSORT(random_set, 10, k)<<endl;
    return 0;
}