#include<iostream>
#include<fstream>
#include<cstdio>
#include<queue>
#include<ctime>
#include "heap.h"


int main()
{
    int number_of_bags, number_of_time;
    cin>>number_of_bags;
    cin>>number_of_time;
    Heap candy_in_each_bag(number_of_bags);
    for(int i=0; i<number_of_bags; i++)
    {
        int seat=0;
        cin>>seat;
        candy_in_each_bag.insert(seat);
    }

    int total_taken=0;
    for(int i=0; i<number_of_time; i++)
    {
        int max=candy_in_each_bag.deleteKey();
        total_taken=total_taken+max;
        candy_in_each_bag.insert(max/2);
    }
    cout<<total_taken;
    return 0;
}