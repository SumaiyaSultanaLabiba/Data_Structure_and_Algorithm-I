#include<iostream>
using namespace std;


class Heap
{
    private:
    int* array;
    int start_index;
    int end_index;
    int capacity;

    public:
    Heap(int size)
    {
      this->capacity=size+1;
      this->array=new int[this->capacity];
      this->start_index=1;
      this->end_index=1;
    }

    Heap(vector<int> numbers)
    {
      this->capacity=numbers.size()+1;  
      this->array=new int[this->capacity];
      this->start_index=1;
      this->end_index=1;
    }

    ~Heap()
    {
        delete[] this->array;
    }

    void front_heapify(int root_index)
    { 
      int left_child_index=2*root_index;
      int right_child_index=(2*root_index)+1;
      int largest=root_index;
      if(left_child_index<=this->size() && this->array[left_child_index]>this->array[root_index])
      {
        largest=left_child_index;
      }
      if(right_child_index<=this->size() && this->array[right_child_index]>this->array[largest])
      {
        largest=right_child_index;
      }
      if(largest!=root_index)
      {
        int temp=this->array[root_index];
        this->array[root_index]=this->array[largest];
        this->array[largest]=temp;
        this->front_heapify(largest);
      }
    }

    void back_heapify(int root_index)
    {
      int parent_index=root_index/2;
      int largest=parent_index;
      if(parent_index>=1 && this->array[root_index]>this->array[parent_index])
      {
        int temp=this->array[root_index];
        this->array[root_index]=this->array[parent_index];
        this->array[parent_index]=temp;
        this->back_heapify(parent_index);
      }
    }

    void insert(int number)
    {
      if(this->capacity==this->size()) return;
      this->array[this->end_index++]=number;
      this->back_heapify(this->end_index-1);
    }

    int deleteKey()
    {
        if(this->size()==0) return -1;
        int return_value=this->array[this->start_index];
        this->array[this->start_index]=this->array[this->end_index-1];
        this->end_index--;
        this->front_heapify(this->start_index);
        return return_value;
    }

    int deleteKeyIndex(int index)
    {
      int returnable_item=array[index];
      int last_item=array[end_index-1];
      array[index]=last_item;
      this->end_index--;
      if(returnable_item>last_item) this->front_heapify(index);
      else if(returnable_item<last_item) this->back_heapify(index);
      else ;//already heapified
      return returnable_item;
    }


    int size()
    {
        return this->end_index-this->start_index;
    }

    int getMax()
    {
        if(this->size()==0) return -1;
        return this->array[this->start_index];
    }

    void print()
    {
        for(int i=0; i<this->size(); i++)
        {
            cout<<this->array[i+1]<<", ";
        }
        cout<<endl;
    }
};


void heapsort(vector<int>&v)
{
   Heap h(v);
   int number_of_elements=v.size();
   for(int i=0; i<number_of_elements; i++)
   {
    h.insert(v[i]);
   }
   
   for(int i=0; i<number_of_elements; i++)
   {
    v[i]=h.deleteKey();
   }
}
