#include<iostream>
#include<fstream>
#include<cstdio>
#include<queue>
#include<ctime>
#include "heap.h"


int main()
{
    int number_of_rows, number_of_candidates;
    cin>>number_of_rows;
    cin>>number_of_candidates;
    Heap seat_in_each_row(number_of_rows);
    for(int i=0; i<number_of_rows; i++)
    {
        int seat=0;
        cin>>seat;
        seat_in_each_row.insert(seat);
    }

    int total_price=0;
    for(int i=0; i<number_of_candidates; i++)
    {
        int max=seat_in_each_row.deleteKey();
        total_price=total_price+max;
        seat_in_each_row.insert(max-1);
    }
    cout<<total_price;
    return 0;
}