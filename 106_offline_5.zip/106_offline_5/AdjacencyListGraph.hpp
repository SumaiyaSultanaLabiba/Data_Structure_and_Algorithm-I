#ifndef ADJACENCY_LIST_GRAPH_H
#define ADJACENCY_LIST_GRAPH_H

#include "GraphADT.hpp"
#include "queue.h"
#include <string.h>

class AdjacencyListGraph : public GraphADT
{
private:
    // TODO: Take necessary private members
    arrayList<int> vertices;
    arrayList<linkedList<int>> all_neighbours;
    //private helper methods
    int get_index_from_vertices(int u)
    {
        for(int i=0; i<this->vertices.Size(); i++)
        {
            if(this->vertices[i]==u) return i;
        }
        return -1;
    }

    linkedList<int> BuildShortestPath(int u, int v)
    {
      linkedList<int> shortestPath;
      linkedList<int> complete_graph;

      //starting Breadth-First-Search
      arrayList<string> colour_chart;
      int preserve_u=u;
      int preserve_v=v;
      for(int i=0; i<this->vertices.Size(); i++)
      {
        colour_chart.append("white");
      }
      colour_chart.setValue(this->get_index_from_vertices(u), "gray");
      ListQueue queue;
      queue.enqueue(u);
      while(!queue.empty())
      {
        u=queue.dequeue();
        complete_graph.append(u);
        for(int i=0; i<this->GetNeighbors(u).Size(); i++)
        {
            v=this->GetNeighbors(u)[i];
            if(colour_chart.getValue(this->get_index_from_vertices(v))=="white")
            {
            colour_chart.setValue(this->get_index_from_vertices(v), "gray");    
            queue.enqueue(v);
            }
        }
        colour_chart.setValue(this->get_index_from_vertices(u), "black");
      }
      u=preserve_u;
      v=preserve_v;
      //ending Breadth-First-Search
      
      if(!complete_graph.is_present(v)) return shortestPath;
      int index_u=complete_graph.getIndex(u);
      int index_v=complete_graph.getIndex(v);
      int latest_element_of_complete_graph=0;
      for(int i=index_u; i<=index_v; i++)
      {
        if(complete_graph[i]==u) {shortestPath.append(u); latest_element_of_complete_graph=u;}
        if(complete_graph[i]==v) {shortestPath.append(v); latest_element_of_complete_graph=v;}
        if(this->GetNeighbors(latest_element_of_complete_graph).is_present(complete_graph[i]))
        {shortestPath.append(complete_graph[i]); latest_element_of_complete_graph=complete_graph[i];}
      }
      return shortestPath;
    }

public:    
    void AddNode(int v) override
    {
        //TODO: Add a new node v and resize the matrix if your current matrix is almost going to be full.
        if(!this->vertices.is_present(v))
        {
            this->vertices.append(v);
            linkedList<int> new_list;
            this->all_neighbours.append(new_list);
        }
    }

    void AddEdge(int u, int v) override
    {
        //TODO: Add a new edge between the nodes u and v
        if(this->CheckEdge(u, v)) return;
        if(!this->vertices.is_present(u)) this->AddNode(u);
        if(!this->vertices.is_present(v)) this->AddNode(v);
        int index_u=this->get_index_from_vertices(u);
        int index_v=this->get_index_from_vertices(v);
        this->all_neighbours[index_u].append(v);
        this->all_neighbours[index_v].append(u);
    }


    bool CheckEdge(int u, int v) override
    {
        //TODO: Check whether there is an edge between two nodes u and v
        if(!this->vertices.is_present(u) || !this->vertices.is_present(v)) return false;
        if(this->all_neighbours[this->get_index_from_vertices(u)].is_present(v) && this->all_neighbours[this->get_index_from_vertices(v)].is_present(u))
        return true;
        else return false;
    }


    void RemoveNode(int v) override
    {
        //TODO: Remove a node.
        if(!this->vertices.is_present(v)) return;
        for(int i=0; i<this->vertices.Size(); i++)
        {
            if(this->all_neighbours[i].is_present(v)) this->all_neighbours[i].delete_item(v);
        }
        this->all_neighbours[this->get_index_from_vertices(v)].clear();
        linkedList<int> new_list;
        this->all_neighbours.append(new_list);
    }


    void RemoveEdge(int u, int v) override
    {
        //TODO: remove an edge
        if(!this->CheckEdge(u, v)) return;
        if(!this->vertices.is_present(u)) return;
        if(!this->vertices.is_present(v)) return;
        int index_u=this->get_index_from_vertices(u);
        int index_v=this->get_index_from_vertices(v);
        this->all_neighbours[index_u].delete_item(v);
        this->all_neighbours[index_v].delete_item(u);
    }

    bool CheckPath(int u, int v) override
    {
        //TODO: Return true if there is a path between nodes u and v. Otherwise return false
        if(!this->BuildShortestPath(u, v).Size()>0) return false;
        return true;
    }

    void FindShortestPath(int u, int v) override
    {
        //TODO: Find the shortest path between the nodes u and v and print it.
        this->BuildShortestPath(u, v).print();
    }


    int FindShortestPathLength(int u, int v) override
    { 
        //TODO: Return the shortest path length between nodes u and v if any such path exists. Otherwise return -1. 
        return this->BuildShortestPath(u, v).Size();    
    }

        
    arrayList<int> GetNeighbors(int u) override
    {
        //TODO: Return the list of neighbors.
        arrayList<int> neighbor;
        if(!this->vertices.is_present(u)) return neighbor;
        for(int i=0; i<this->all_neighbours[this->get_index_from_vertices(u)].Size(); i++)
        {
            neighbor.append(this->all_neighbours[this->get_index_from_vertices(u)][i]);
        }
        return neighbor;
    }

};


#endif // ADJACENCY_LIST_GRAPH_H
