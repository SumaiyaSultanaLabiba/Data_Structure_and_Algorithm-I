#ifndef LIST_H
#define LIST_H

template<typename T>
class list
{
    public:
    virtual void print()=0;
    virtual void insert(T item)=0;
    virtual int Size()=0;
    virtual T delete_cur()=0;
    virtual void append(T item)=0;
    virtual void prev(int n)=0;
    virtual void next(int n)=0;
    virtual bool is_present(T n)=0;
    virtual void clear()=0;
    virtual void delete_item(T item)=0;
    virtual void swap_ind(int ind1, int ind2)=0;

};

#endif // LIST_H
