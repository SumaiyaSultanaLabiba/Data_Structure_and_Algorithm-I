#include <iostream>
#include <cstdio>

int main() {
    std::cout << "This is console output\n";

    if (freopen("my_output.txt", "w", stdout) == nullptr) {
        std::cerr << "Failed to redirect stdout!\n";
        return 1;
    }
    std::cout << "This should go to the file\n";
    return 0;
}