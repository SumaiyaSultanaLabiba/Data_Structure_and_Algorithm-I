#include <iostream>
#include "list.hpp"
using namespace std;


template<typename T>
class linkedList: public list<T>
{
    // declare head, tail, cur and other variables you need
    private:
    typedef struct node
    {
    T element;
    struct node* next;
    struct node* prev;
    }node;
    node* head;
    node* tail;
    node* cur;

public:    
linkedList()
{
    // implement initialization
   this->head=new node();
   this->head->element;
   this->head->next=NULL;
   this->head->prev=NULL;
   this->cur=NULL;
   this->tail=this->head;
}

~linkedList()
{
    // implement destruction of list
    node* temp = this->head;
    while (temp != nullptr) 
    {
        node* next_node = temp->next;
        delete temp;
        temp = next_node;
    }
}

void print()
{
    // implement list printing
    if(this->cur==NULL)
    {
        cout<<" "<<endl;
    }
    else
    {
    node* temp=this->head;
    while(temp!=NULL)
    {
       cout<<temp->element; 
       cout<<"  ";
       temp=temp->next; 
    }
    cout<<endl;
    }
}

void insert(T item)
{
    // implement insert function
    node* new_node=new node();
    new_node->element=item;
    new_node->next=NULL;
    new_node->prev=NULL;
    if(this->cur==this->tail)
    {
        new_node->prev=this->tail;
        this->tail->next=new_node;
        this->tail=new_node;
        this->cur=this->tail;
    }
    else if(this->head==this->tail&&this->cur==NULL)
    {
      this->head->element=item;
      this->cur=this->head;
    }
    else
    {
      new_node->prev=this->cur;
      new_node->next=this->cur->next;
      if(this->cur->next!=nullptr) this->cur->next->prev=new_node;
      this->cur->next=new_node;
      this->cur=new_node;
    }
}

int Size()
{
    // implement size function
    if(this->cur==nullptr) return 0;
    int size=0;
    node* temp=this->head;
    while(temp!=NULL)
    {
       size++;
       temp=temp->next; 
    }
    return size;
}



T delete_cur()
{
    // implement deletion of current index function
    T deletable_item=this->cur->element;
    if(this->head==this->tail) {delete this->head;} 
    else if(this->cur==this->head)
    {
      this->head=this->head->next;
      this->cur=this->cur->next;
      delete this->cur->prev;
      this->cur->prev=NULL;
    }
    else if(this->cur==this->tail)
    {
      this->tail=this->tail->prev;
      this->cur=this->tail;
      delete this->cur->next;
      this->tail->next=NULL;
    }
    else
    {
      this->cur->prev->next=this->cur->next;
      this->cur->next->prev=this->cur->prev;
      node* temp=this->cur;
      this->cur=this->cur->next;
      delete temp;
    }
    return deletable_item;
}


void append(T item)
{
    // implement append function
    if(this->cur==NULL)
    {
        this->insert(item);
    }
    else
    {
    node* temp=this->cur;
    this->cur=this->tail;
    this->insert(item);
    this->cur=temp;
    }
}


void prev(int n)
{
    // implement prev function
    for(int i=0; i<n; i++)
    {
        if(this->cur==this->head) break;
        this->cur=this->cur->prev;
    }
}

void next(int n)
{
    // implement next function
    for(int i=0; i<n; i++)
    {
        if(this->cur==this->tail) break;
        this->cur=this->cur->next;
    }
}

bool is_present(T n)
{
    // implement presence checking function
    node* temp=this->head;
    while(temp!=NULL)
    { 
       if(temp->element==n) return true;
       temp=temp->next; 
    }
    return false;
}

void clear()
{
    // implement list clearing function
    while (this->head != nullptr) 
    {
        node* temp = this->head;
        this->head = this->head->next;
        delete temp;
    }
    this->tail = nullptr;
    this->cur = nullptr;

}

void delete_item(T item)
{
    // implement item deletion function
    node* temp=this->head;
    int found=0;
    while(temp!=NULL)
    {
       if(temp->element==item)
       {
        found=1;
        if(temp==this->cur&&this->cur==this->head)  this->cur=this->cur->next;
        if(temp==this->cur&&this->cur==this->tail)  this->cur=this->cur->prev;
        if(temp==this->cur&&this->cur!=this->head&&this->cur!=this->tail)  this->cur=this->cur->next;
        if(this->head==this->tail)
        {
            delete this->head;
            this->head = nullptr;
            this->tail = nullptr;
            this->cur = nullptr;
            return;
        } 
        else if(temp==this->head)
             {
                this->head=this->head->next;
                temp=temp->next;
                delete temp->prev;
                temp->prev=NULL;
             }
        else if(temp==this->tail)
             {
                this->tail=this->tail->prev;
                temp=this->tail;
                delete temp->next;
                this->tail->next=NULL;
             }
        else
             {
             temp->prev->next=temp->next;
             temp->next->prev=temp->prev;
             node* p=temp;
             temp=temp->next;
             delete p;
             }
        break;
       } 
       temp=temp->next; 
    }
    if(found==0) cout<<item<<" not found"<<endl;
}

void swap_ind(int ind1, int ind2)
{
    // implement swap function
    node* temp;
    temp=this->head;
    int i=0;
    while(i<ind1)
    {
      temp=temp->next;  
      i++;  
    }
    node* temp1=temp;
    temp=this->head;
    i=0;
    while(i<ind2)
    {
      temp=temp->next;  
      i++;  
    }
    node* temp2=temp;
    int t=temp1->element;
    temp1->element=temp2->element;
    temp2->element=t;
}

bool operator==(linkedList<T> other)
{
    if(this->Size()!=other.Size()) return false;
    else
    {
        node* temp_this=this->head;
        node* temp_other=other.head;
        for(int i=0; i<this->Size(); i++)
        {
            if(temp_this->element!=temp_other->element) return false;
            temp_this=temp_this->next;
            temp_other=temp_other->next;
        }
        return true;
    }
}

T operator[](int index)
{
    node* temp=this->cur;
    for(int i=0; i<index; i++)
    {
        temp=temp->next;
    }
    return temp->element;
}

int getIndex(T item)
{
    node* temp=this->head;
    for(int i=0; i<this->Size(); i++)
    {
     if(temp->element==item) return i;
     else temp=temp->next;
    }
    return -1;
}

};
// you can define helper functions you need