#ifndef ADJACENCY_MATRIX_GRAPH_H
#define ADJACENCY_MATRIX_GRAPH_H

#include "GraphADT.hpp"

class AdjacencyMatrixGraph : public GraphADT
{
private:
    //TODO: Consider necessary private members as per your discretion
    
    //private helper methods
    void resizeMatrix()
    {
        //TODO: you need to resize your matrix when you will less data or more data
        //this is already handled in the arrayList implementation
    }

public:
    void AddNode(int v) override {
    resizeMatrix();
    
}

    void AddEdge(int u, int v) override
    {
        //TODO: Add a new edge between the nodes u and v
        
    }

    bool CheckEdge(int u, int v) override
    {
        //TODO: Check whether there is an edge between two nodes u and v
        
    }

    void RemoveNode(int v) override
    {
        //TODO: Remove a node.
        
    }

    void RemoveEdge(int u, int v) override
    {
        //TODO: remove an edge
        
    }

    bool CheckPath(int u, int v) override
    {
        //TODO: Return true if there is a path between nodes u and v. Otherwise return false
        
    }

    void FindShortestPath(int u, int v) override
    {
        //TODO: Find the shortest path between the nodes u and v and print it.
       
    }

    int FindShortestPathLength(int u, int v) override
    {
        //TODO: Return the shortest path length between nodes u and v if any such path exists. Otherwise return -1.
        
    }

    arrayList<int> GetNeighbors(int u) override
    {
        //TODO return a list of neighbors of node u
        
    }

};

#endif // ADJACENCY_MATRIX_GRAPH_H
