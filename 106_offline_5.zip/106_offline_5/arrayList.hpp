#include <iostream>
#include "list.hpp"
using namespace std;



template<typename T>
class arrayList:public list<T>
{
    private:
    T *array;
    // declare variables you need
    int capacity;//the total capacity of the arrayList
    int size;//how many elements are actually present in the space
    int cur;// stores index of the current position

public:
arrayList()
{
    // implement initialization
    this->capacity=1;
    this->size=0;
    this->cur=-1;
    this->array=new T[this->capacity];
}

arrayList(int number_of_elements, T value)
{
    // implement initialization
    this->capacity=1;
    this->size=0;
    this->cur=-1;
    this->array=new T[this->capacity];
    for(int i=0; i<number_of_elements; i++)
    {
        this->array[i]=value;
    }
}

void print()
{
    // implement list printing
    if(this->size==0) cout<<" "<<endl;
    else
    {
        for(int i=0; i<this->size; i++)
        {
            cout<<this->array[i];
            cout<<" ";
        }
        cout<<endl;
    }
}

~arrayList()
{
    // implement destruction of list
    delete[] this->array;
}

void increase_capacity()
{
    // implement capacity increase
    if(this->size>this->capacity/2)
    {
        this->capacity*=2;
        this->cur=this->cur;
        this->size=this->size;
        T* new_list= new T[this->capacity];
        for(int i=0; i<this->size; i++)
        {
            new_list[i]=this->array[i];
        }
        delete[] this->array;
        this->array=new_list;
    }
}

void decrease_capacity()
{
    // implement capacity decrease
    if(this->size<this->capacity/4)
    {
        this->capacity/=2;
        this->cur=this->cur;
        this->size=this->size;
        T* new_list= new T[this->capacity];
        for(int i=0; i<this->size; i++)
        {
            new_list[i]=this->array[i];
        }
        delete[] this->array;
        this->array=new_list;
    }
}



void insert(T item)
{
    // implement insert function
    this->size+=1;
    this->increase_capacity();
    this->cur++;
    if(this->cur==0) 
    {
        this->array[0]=item;
    }
    else
    {for(int i=this->size-1; i>=this->cur; i--)
    {
       this->array[i]=this->array[i-1]; 
    }
    this->array[this->cur]=item;}
}


void insert_front(T item)
{
    int temp_position=this->cur;
    this->cur=0;
    insert(item);
    this->cur=temp_position;
}

int Size()
{
    // implement size function
    return this->size;
}


T delete_cur()
{
    // implement deletion of current index function
    T temp=this->array[this->cur];
    for(int i=this->cur; i<this->size-1; i++)
    {
       this->array[i]=this->array[i+1]; 
    }
    if(this->cur==this->size-1)
    {
        this->cur--;
    }
    this->size-=1;
    this->decrease_capacity();
    return temp;
}

T delete_front()
{
    int temp_position=this->cur;
    this->cur=0;
    T return_value=delete_cur();
    this->cur=temp_position;
    return return_value;
}

void append(T item)
{
    // implement append function
    if(this->cur==-1) this->cur=0;
    this->size+=1;
    this->increase_capacity();
    this->array[this->size-1]=item;
}


void prev(int n)
{
    // implement prev function
    for(int i=0; i<n; i++)
    {
        this->cur--;
    }
    if(this->cur<0) this->cur=0;
}

void next(int n)
{
    // implement next function
    for(int i=0; i<n; i++)
    {
        this->cur++;
    }
    if(this->cur>this->size-1) this->cur=this->size-1;
}

bool is_present(T n)
{
    // implement presence checking function
    int i=0;
    for(i=0; i<this->size; i++)
    {
        if(this->array[i]==n) return true;
    }
    return false;
}

void clear()
{
    // implement list clearing function
    this->size=0;
    this->capacity=2;
    this->cur=-1;
}

void delete_item(T item)
{
    // implement item deletion function
    if(this->is_present(item))
    {
    for(int i=0; i<this->size; i++)
    {
        if(this->array[i]==item)
        { 
            if(this->cur==this->size-1)
            {
                this->cur--;
            }
            int temp=this->cur;
            this->cur=i;
            this->delete_cur();
            this->cur=temp;
           break;
        }
    }
    }
    else
    {
        cout<<" not found"<<endl;
    }
}

void swap_ind(int ind1, int ind2)
{
    // implement swap function
    T temp=this->array[ind1];
    this->array[ind1]=this->array[ind2];
    this->array[ind2]=temp;
}

T operator[](int index)
{
    return this->array[index];
}

bool operator==(arrayList<T> other)
{
    if(this->Size()!=other.Size()) return false;
    else
    {
        for(int i=0; i<this->Size(); i++)
        {
            if(this->array[i]!=other.array[i]) return false;
        }
        return true;
    }
}


int getIndex(T item)
{
    for(int i=0; i<this->Size(); i++)
    {
        if(this->array[i]==item) return i;
    }
    return -1;
}

void setValue(int index, T value)
{
    this->array[index]=value;
}

T getValue(int index)
{
    return this->array[index];
}
};


template <typename T>
std::ostream& operator<<(std::ostream& os,arrayList<T>& list) {
    for (int i = 0; i < list.Size(); ++i) {
        os << list[i];
        if (i != list.Size() - 1) os << " ";
    }
    return os;
}
// you can define helper functions you need