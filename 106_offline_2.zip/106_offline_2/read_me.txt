This is a simple implementation of Stack ADT using two different data structures---Array list and Linked list. 

Here being provided with the stack.h header file containing the abstract classes: stack, array_list and linked_list, a concrete implementation of all abstract methods is made in array_list.cpp and linked_list.cpp files. For array list implementation, a dynamic array is used whereas a singly linked list is taken for the linked list part. Then  for checking the Stack functionalities using either of the two data structures, test.cpp file comes with a number of  test cases, covering a wide variety of regular and edge cases. As the Stack implementation has passed for all test cases, it has finally proved the correctness of our program.

For compiling test.cpp:    g++ -std=c++11 test.cpp arraystack.cpp liststack.cpp -o stack_test
For running:  ./stack_test