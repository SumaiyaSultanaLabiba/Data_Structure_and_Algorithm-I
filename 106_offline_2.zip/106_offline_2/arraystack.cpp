#include "stack.h"
#include <iostream>

// Constructor implementation
ArrayStack::ArrayStack(int initial_capacity) {
    // TODO: Initialize data members (data, capacity, current_size)
    this->capacity=initial_capacity;
    this->current_size=0;
    // TODO: Allocate memory for the array with the specified initial capacity
    this->data=new int[initial_capacity];
}

// Destructor implementation
ArrayStack::~ArrayStack() {
    // TODO: Free the dynamically allocated memory for the array
    delete[] this->data;
}

// Push implementation
void ArrayStack::push(int item) {
    // TODO: Check if the array is 50% full (current_size >= capacity/2)
    // TODO: If 50% full, resize the array to double its current capacity
    if(this->current_size>=this->capacity/2)
    {
        this->resize(this->capacity*2);
    }
    // TODO: Add the new element to the top of the stack and increment current_size
    if(this->current_size==0) this->data[0]=item;
    else this->data[this->current_size]=item;
    this->current_size++;
}



// Pop implementation
int ArrayStack::pop() {
    // TODO: Check if the stack is empty, display error message if it is
    if(this->empty())
    {
    std::cout<<"Cannot pop from an empty stack, return_value=-1"<<std::endl;
    return -1;
    }
    // TODO: Decrement current_size and return the element at the top of the stack
    // TODO: If the array is less than 25% full, resize it to half its current capacity
    // TODO: Return the popped element
    else
    {
      int return_value=this->data[this->current_size-1];
      this->current_size--;
      this->resize(this->capacity/2);
      return return_value;
    }
}



// Clear implementation
void ArrayStack::clear() {
    // TODO: No need to free memory, just logically clear the stack
    for(int i=this->current_size; i>=1; i--)
    {
        pop();
    }
    // TODO: Reset the stack to be empty (set current_size to 0)
    this->current_size=0;
}




// Size implementation
int ArrayStack::size() const {
    // TODO: Return the number of elements currently in the stack (current_size)
    return this->current_size;
}




// Top implementation
int ArrayStack::top() const {
    // TODO: Check if the stack is empty, display error message if it is
    if(this->empty()) 
    {
    std::cout<<"Empty Stack has No Top Element  ,return value=-1";
    return -1;
    }
    // TODO: Return the element at the top of the stack without removing it
    else return this->data[this->current_size-1];
}



// Empty implementation
bool ArrayStack::empty() const {
    // TODO: Return whether the stack is empty (current_size == 0)
    if(this->current_size==0) return true;
    else return false;
}




// Print implementation
void ArrayStack::print() const {
    // TODO: Print stack elements from top to bottom in the format: |elem1, elem2, ..., elemN>
    std::cout<<"|";
    for(int i=this->current_size-1; i>=0; i--)
    {
        std::cout<<this->data[i];
        if(i==0) break;
        std::cout<<", ";
    }
    std::cout<<">"<<std::endl;
}




// Resize implementation
void ArrayStack::resize(int new_capacity) {
    //decision making whether it is really necessary to resize the array and determine to make larger/shrink
    bool is_larger_needed=false;
    bool is_smaller_needed=false;
    if((this->current_size<=this->capacity/4)&&this->capacity/2>=10) is_smaller_needed=true;
    if(this->current_size>=this->capacity/2) is_larger_needed=true;
    
    if(is_larger_needed)
    {
        // TODO: Create a new array with the new capacity
        int* new_array=new int[this->capacity*2];
        // TODO: Copy elements from the old array to the new array
        for(int i=0; i<this->current_size; i++)
        {
            new_array[i]=this->data[i];
        }
        // TODO: Delete the old array
        delete[] this->data;
        // TODO: Update the data pointer and capacity
        this->data=new_array;
        this->capacity*=2;
    }

    if(is_smaller_needed)
    {
        // TODO: Create a new array with the new capacity
        int* new_array=new int[this->capacity/2];
        // TODO: Copy elements from the old array to the new array
        for(int i=0; i<this->current_size; i++)
        {
            new_array[i]=this->data[i];
        }
        // TODO: Delete the old array
        delete[] this->data;
        // TODO: Update the data pointer and capacity
        this->data=new_array;
        this->capacity/=2;
    }
}
