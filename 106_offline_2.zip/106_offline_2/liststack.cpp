#include "stack.h"
#include <iostream>

// Constructor implementation
ListStack::ListStack() {
    // TODO: Initialize head to nullptr
    this->head=nullptr;
    // TODO: Initialize current_size to 0
    this->current_size=0;
}


// Destructor implementation
ListStack::~ListStack() {
    // TODO: Deallocate all nodes in the linked list
    // TODO: Consider using the clear() method
    this->clear();
}


// Push implementation
void ListStack::push(int item) {
    // TODO: Create a new node with the given item
    struct Node* new_node=new struct Node(item, nullptr);
    if(new_node==NULL) std::cout<<"No node is created!"<<std::endl;
    // TODO: Make the new node point to the current head
    new_node->next=this->head;
    // TODO: Update head to point to the new node
    this->head=new_node;
    // TODO: Increment current_size
    this->current_size++;
}


// Pop implementation
int ListStack::pop() {
    // TODO: Check if the stack is empty, display error message if it is
    if(this->empty())
    {
    std::cout<<"Cannot pop from an empty stack, return_value=-1"<<std::endl;
    return -1;
    }
    // TODO: Store the data from the head node
    // TODO: Update head to point to the next node
    // TODO: Delete the old head node
    // TODO: Decrement current_size
    // TODO: Return the stored data
    else
    {
        struct Node* pop_node=this->head;
        int pop_value=this->head->data;
        this->head=this->head->next;
        delete pop_node;
        this->current_size--;
        return pop_value;
    }
}


// Clear implementation
void ListStack::clear() {
    // TODO: Traverse the linked list, deleting each node
    while(this->head!=nullptr)
    {
        this->pop();
    }
    // TODO: Reset head to nullptr
    this->head=nullptr;
    // TODO: Reset current_size to 0
    this->current_size=0;
}


// Size implementation
int ListStack::size() const {
    // TODO: Return the current size (current_size)
    return this->current_size;
}


// Top implementation
int ListStack::top() const {
    // TODO: Check if the stack is empty, display error message if it is
    if(this->empty())
    {
        std::cout<<"Empty Stack has No Top Element  ,return value=";
        return -1;
    }
    // TODO: Return the data from the head node without removing it
    return this->head->data;
}


// Empty implementation
bool ListStack::empty() const {
    // TODO: Return whether head is nullptr
    if(this->head==nullptr) return true;
    else return false;
}


// Print implementation
void ListStack::print() const {
    // TODO: Print stack elements from top to bottom in the format: |elem1, elem2, ..., elemN>
    // TODO: Traverse the linked list from head, printing each node's data
    std::cout<<"|";
    struct Node* cur=this->head;
    for(int i=this->current_size; i>=1; i--)
    {
        std::cout<<cur->data;
        if(i==1) break;
        std::cout<<",";
        cur=cur->next;
    }
    std::cout<<">"<<std::endl;
}
