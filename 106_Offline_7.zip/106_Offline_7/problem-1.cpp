#include<iostream>
using namespace std;


int max_of_array(int work[], int number_of_work)
{
    int max=work[0];
    for(int i=1; i<number_of_work; i++)
    {
        if(max<work[i]) max=work[i];
    }
    return max;
}


int sum(int work[], int start_index, int end_index)
{
    int sum=0;
    for(int i=start_index; i<=end_index; i++)
    {
        sum+=work[i];
    }
    return sum;
}


int task_allocation(int work[], int number_of_work, int number_of_employees)
{
   if(number_of_work<number_of_employees) return -1;
   else if(number_of_work==number_of_employees) return max_of_array(work, number_of_work);
   else
   {
    int lowest_bound_of_maximum=max_of_array(work, number_of_work);
    int highest_bound_of_maximum=sum(work, 0, number_of_work-1);
    int average_value=0;
    int employee_count_related_to_avearge_value;


    label:
    average_value=(lowest_bound_of_maximum+highest_bound_of_maximum)/2;
    employee_count_related_to_avearge_value=1;

    if(lowest_bound_of_maximum<=highest_bound_of_maximum)
    {
        int sum=0;
        for(int i=0; i<number_of_work; i++)
        {
            if(sum+work[i]>average_value)
            {
                sum=0;
                employee_count_related_to_avearge_value++;
            }
            sum+=work[i];
        }

        if(employee_count_related_to_avearge_value>number_of_employees)
        {
          lowest_bound_of_maximum=average_value+1;
          goto label;
        }

        else if(employee_count_related_to_avearge_value<number_of_employees)
        {
          highest_bound_of_maximum=average_value-1;
          goto label;
        }

        else
        {
          highest_bound_of_maximum=average_value-1;
          goto label;
        }
    }
    return lowest_bound_of_maximum;
   }
}



int main()
{
    int number_of_work;
    int number_of_employees;
    int work[number_of_work];

    cin>>number_of_work;
    cin>>number_of_employees;
    for(int i=0; i<number_of_work; i++)
    {
        cin>>work[i];
    }

    cout<<task_allocation(work, number_of_work, number_of_employees);
    return 0;
}

