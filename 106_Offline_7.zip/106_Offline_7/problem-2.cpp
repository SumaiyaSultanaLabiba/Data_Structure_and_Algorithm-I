#include<iostream>
using namespace std;


bool is_possible_to_allocate(int seats[], int number_of_seats, int number_of_benches, int number_of_new_students)
{
   int seats_in_each_bench=number_of_seats/number_of_benches;
   int bench[seats_in_each_bench]={0};
   int total_number_of_available_seats=0;
   int index_at_seats=0;

   label:
   for(int i=0; i<seats_in_each_bench; i++)
   {
    bench[i]=seats[index_at_seats++];
   }

   for(int i=0; i<seats_in_each_bench; i++)
   {
    if(bench[i]==0 && (i>0 && bench[i-1]==1)) bench[i]=-1;
    if(bench[i]==0 && ((i>0 && bench[i-1]==2) || (i<seats_in_each_bench-1 && bench[i+1]==2))) bench[i]=-1;
   }

   for(int i=0; i<seats_in_each_bench; i++)
   {
    if(bench[i]==0) total_number_of_available_seats++;
    cout<<bench[i]<< ",";
   }
   cout<<endl;
   
   if(total_number_of_available_seats>=number_of_new_students) return true;
   if(total_number_of_available_seats<number_of_new_students && index_at_seats<number_of_seats) goto label;
   return false;
}



int main()
{
    int number_of_seats;
    int number_of_benches;
    int number_of_new_students;
    int seats[number_of_seats];
    
    cin>>number_of_seats;
    cin>>number_of_benches;
    for(int i=0; i<number_of_seats; i++)
    {
        cin>>seats[i];
    }
    cin>>number_of_new_students;

    if(is_possible_to_allocate(seats, number_of_seats, number_of_benches, number_of_new_students)) cout<<"true";
    else cout<<"false";

    return 0;
}