#include <stdio.h>
#include <stdlib.h>

//flag=0 means the delete_cur function is by main program
//flag=1 means the delete_cur function is called by delete_item function
int flag=0;


typedef struct 
{
    int *array;
    // declare variables you need
    int capacity;//the total capacity of the arrayList
    int size;//how many elements are actually present in the space
    int cur;// stores index of the current position
} arrayList;

void init(arrayList* list)
{
    // implement initialization
    list->capacity=1;
    list->size=0;
    list->cur=-1;
    list->array=(int*)malloc(sizeof(int)*list->capacity);
}

void print(arrayList* list)
{
    // implement list printing
    if(list->size==0) printf("[.]\n");
    else
    {
        printf("[");
        for(int i=0; i<list->size; i++)
        {
            printf("%d ", list->array[i]);
            if(i==list->cur) printf("|");
        }
        printf("]\n");
    }
}

void free_list(arrayList* list)
{
    // implement destruction of list
    free(list->array);
}

void increase_capacity(arrayList* list)
{
    // implement capacity increase
    if(list->size>list->capacity/2)
    {
        if(list->capacity!=1) printf("Capacity increased from %d to %d\n", list->capacity, list->capacity*2);
        list->capacity*=2;
        list->cur=list->cur;
        list->size=list->size;
        arrayList new_list;
        new_list.capacity=list->capacity;
        new_list.cur=list->cur;
        new_list.size=list->size;
        new_list.array=(int*)malloc(sizeof(int)*new_list.capacity);
        for(int i=0; i<list->size; i++)
        {
            new_list.array[i]=list->array[i];
        }
        list->array=(int*)malloc(sizeof(int)*list->capacity);
        for(int i=0; i<list->size; i++)
        {
            list->array[i]=new_list.array[i];
        }
        free(new_list.array);
    }
}

void decrease_capacity(arrayList* list)
{
    // implement capacity decrease
    if(list->size<list->capacity/4)
    {
        printf("Capacity decreased from %d to %d\n", list->capacity, list->capacity/2);
        list->capacity/=2;
        list->cur=list->cur;
        list->size=list->size;
        arrayList new_list;
        new_list.capacity=list->capacity;
        new_list.cur=list->cur;
        new_list.size=list->size;
        new_list.array=(int*)malloc(sizeof(int)*new_list.capacity);
        for(int i=0; i<list->size; i++)
        {
            new_list.array[i]=list->array[i];
        }
        list->array=(int*)malloc(sizeof(int)*list->capacity);
        for(int i=0; i<list->size; i++)
        {
            list->array[i]=new_list.array[i];
        }
        free(new_list.array);
    }
}


void insert(int item, arrayList* list)
{
    // implement insert function
    list->size+=1;
    increase_capacity(list);
    list->cur++;
    if(list->cur==0) 
    {
        list->array[0]=item;
    }
    else
    {for(int i=list->size-1; i>=list->cur; i--)
    {
       list->array[i]=list->array[i-1]; 
    }
    list->array[list->cur]=item;}
    print(list);
}



int delete_cur(arrayList* list)
{
    // implement deletion of current index function
    int temp=list->array[list->cur];
    for(int i=list->cur; i<list->size-1; i++)
    {
       list->array[i]=list->array[i+1]; 
    }
    if(list->cur==list->size-1)
    {
        list->cur--;
    }
    list->size-=1;
    decrease_capacity(list);
    if(flag==0) print(list);
    return temp;
}



void append(int item, arrayList* list)
{
    // implement append function
    if(list->cur==-1) list->cur=0;
    list->size+=1;
    increase_capacity(list);
    list->array[list->size-1]=item;
    print(list);
}

int size(arrayList* list)
{
    // implement size function
    return list->size;
}

void prev(int n, arrayList* list)
{
    // implement prev function
    for(int i=0; i<n; i++)
    {
        list->cur--;
    }
    if(list->cur<0) list->cur=0;
    print(list);
}

void next(int n, arrayList* list)
{
    // implement next function
    for(int i=0; i<n; i++)
    {
        list->cur++;
    }
    if(list->cur>list->size-1) list->cur=list->size-1;
    print(list);
}

int is_present(int n, arrayList* list)
{
    // implement presence checking function
    int i=0;
    for(i=0; i<list->size; i++)
    {
        if(list->array[i]==n) return 1;
    }
    return 0;
}

void clear(arrayList* list)
{
    // implement list clearing function
    list->size=0;
    list->capacity=2;
    list->cur=-1;
    print(list);
}

void delete_item(int item, arrayList* list)
{
    // implement item deletion function
    if(is_present(item, list))
    {
    for(int i=0; i<list->size; i++)
    {
        if(list->array[i]==item)
        { 
            if(list->cur==list->size-1)
            {
                list->cur--;
            }
            int temp=list->cur;
            list->cur=i;
            flag=1;
            delete_cur(list);
            flag=0;
            list->cur=temp;
            print(list);
           break;
        }
    }
    }
    else
    {
        printf("%d not found\n", item);
    }
}

void swap_ind(int ind1, int ind2, arrayList* list)
{
    // implement swap function
    int temp=list->array[ind1];
    list->array[ind1]=list->array[ind2];
    list->array[ind2]=temp;
    print(list);
}

// you can define helper functions you need