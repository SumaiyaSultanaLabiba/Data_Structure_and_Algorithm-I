#include <stdio.h>
#include <stdlib.h>

int flag=0;
//keeps track whether the insert is called by main(flag=0)
//when the insert is called by append, flag=1
typedef struct node
{
    int element;
    struct node* next;
    struct node* prev;
}node;

typedef struct 
{
    // declare head, tail, cur and other variables you need
    node* head;
    node* tail;
    node* cur;
} linkedList;


void init(linkedList* list)
{
    // implement initialization
   list->head=(node*)malloc(sizeof(node));
   list->head->element;
   list->head->next=NULL;
   list->head->prev=NULL;
   list->cur=NULL;
   list->tail=list->head;
}

void free_list(linkedList* list)
{
    // implement destruction of list
    if(list->cur==NULL||list->cur->next==NULL)
    {
        free(list->head);
    }
    else
    {node* temp=list->head;
    while(temp!=list->tail)
    {
       temp=temp->next; 
       free(temp->prev);
    }
    free(list->tail);
    }
}

void print(linkedList* list)
{
    // implement list printing
    if(list->cur==NULL)
    {
        printf("[.]\n");
    }
    else
    {node* temp=list->head;
    printf("[");
    while(temp!=NULL)
    {
       printf("%d ", temp->element); 
       if(temp==list->cur) printf("|");
       temp=temp->next; 
    }
    printf("]\n");}
}

void insert(int item, linkedList* list)
{
    // implement insert function
    node* new_node=(node*)malloc(sizeof(node));
    new_node->element=item;
    new_node->next=NULL;
    new_node->prev=NULL;
    if(list->cur==list->tail)
    {
        new_node->prev=list->tail;
        list->tail->next=new_node;
        list->tail=new_node;
        list->cur=list->tail;
    }
    else if(list->head==list->tail&&list->cur==NULL)
    {
      list->head->element=item;
      list->cur=list->head;
    }
    else
    {
      new_node->prev=list->cur;
      new_node->next=list->cur->next;
      list->cur->next->prev=new_node;
      list->cur->next=new_node;
      list->cur=new_node;
    }
    if(flag==0) print(list);
}

int size(linkedList* list)
{
    // implement size function
    int size=0;
    node* temp=list->head;
    while(temp!=NULL)
    {
       size++;
       temp=temp->next; 
    }
    return size;
}



int delete_cur(linkedList* list)
{
    // implement deletion of current index function
    int deletable_item=list->cur->element;
    if(list->head==list->tail) {free_list(list); init(list);} 
    else if(list->cur==list->head)
    {
      list->head=list->head->next;
      list->cur=list->cur->next;
      free(list->cur->prev);
      list->cur->prev=NULL;
    }
    else if(list->cur==list->tail)
    {
      list->tail=list->tail->prev;
      list->cur=list->tail;
      free(list->cur->next);
      list->tail->next=NULL;
    }
    else
    {
      list->cur->prev->next=list->cur->next;
      list->cur->next->prev=list->cur->prev;
      node* temp=list->cur;
      list->cur=list->cur->next;
      free(temp);
    }
    print(list);
    return deletable_item;
}


void append(int item, linkedList* list)
{
    // implement append function
    if(list->cur==NULL)
    {
        insert(item, list);
    }
    else
    {
    node* temp=list->cur;
    list->cur=list->tail;
    flag=1;
    insert(item, list);
    flag=0;
    list->cur=temp;
    print(list);
    }
}


void prev(int n, linkedList* list)
{
    // implement prev function
    for(int i=0; i<n; i++)
    {
        if(list->cur==list->head) break;
        list->cur=list->cur->prev;
    }
    print(list);
}

void next(int n, linkedList* list)
{
    // implement next function
    for(int i=0; i<n; i++)
    {
        if(list->cur==list->tail) break;
        list->cur=list->cur->next;
    }
    print(list);
}

int is_present(int n, linkedList* list)
{
    // implement presence checking function
    node* temp=list->head;
    while(temp!=NULL)
    { 
       if(temp->element==n) return 1;
       temp=temp->next; 
    }
    return 0;
}

void clear(linkedList* list)
{
    // implement list clearing function
    free_list(list);
    init(list);
    print(list);
}

void delete_item(int item, linkedList* list)
{
    // implement item deletion function
    node* temp=list->head;
    int found=0;
    while(temp!=NULL)
    {
       if(temp->element==item)
       {
        found=1;
        if(temp==list->cur&&list->cur==list->head)  list->cur=list->cur->next;
        if(temp==list->cur&&list->cur==list->tail)  list->cur=list->cur->prev;
        if(temp==list->cur&&list->cur!=list->head&&list->cur!=list->tail)  list->cur=list->cur->next;
        if(list->head==list->tail) {free_list(list); init(list);} 
        else if(temp==list->head)
             {
                list->head=list->head->next;
                temp=temp->next;
                free(temp->prev);
                temp->prev=NULL;
             }
        else if(temp==list->tail)
             {
                list->tail=list->tail->prev;
                temp=list->tail;
                free(temp->next);
                list->tail->next=NULL;
             }
        else
             {
             temp->prev->next=temp->next;
             temp->next->prev=temp->prev;
             node* p=temp;
             temp=temp->next;
             free(p);
             }
        print(list);
        break;
       } 
       temp=temp->next; 
    }
    if(found==0) printf("%d not found\n", item);
}

void swap_ind(int ind1, int ind2, linkedList* list)
{
    // implement swap function
    node* temp;
    temp=list->head;
    int i=0;
    while(i<ind1)
    {
      temp=temp->next;  
      i++;  
    }
    node* temp1=temp;
    temp=list->head;
    i=0;
    while(i<ind2)
    {
      temp=temp->next;  
      i++;  
    }
    node* temp2=temp;
    int t=temp1->element;
    temp1->element=temp2->element;
    temp2->element=t;
    print(list);
}

// you can define helper functions you need