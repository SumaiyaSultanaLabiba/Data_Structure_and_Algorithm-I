#include<iostream>
#include<tuple>
using namespace std;


int maximum(int a, int b, int c)
{
    int return_value=(a>b)? a:b;
    return_value=(return_value>c)? return_value:c;
    return return_value;
}


tuple<int,int,int> max_of_table(int** M, int row, int col)
{
   int max_value=0, max_i=0, max_j=0;
   for(int i=0; i<row; i++)
   {
      for(int j=0; j<col; j++)
      {
         if(max_value<M[i][j])
         {
            max_value=M[i][j];
            max_i=i;
            max_j=j;
         }
      }
   }
   return tuple<int,int,int>(max_value,max_i,max_j);
}



tuple<string,string,int> global_alignment(string first, string second, int gap_penalty, int mismatch_penalty, int match_score)
{
   int m=first.length();
   int n=second.length();
   int M[m+1][n+1];

   for(int i=0; i<=m; i++) M[i][0]=i*gap_penalty;
   for(int j=0; j<=n; j++) M[0][j]=j*gap_penalty;

   for(int i=1; i<=m; i++)
   {
    for(int j=1; j<=n; j++)
    {
     int value_from_up=M[i-1][j]+gap_penalty;
     int value_from_left=M[i][j-1]+gap_penalty;
     int value_from_corner=(first[i-1]==second[j-1])? (M[i-1][j-1]+match_score):(M[i-1][j-1]+mismatch_penalty);
     M[i][j]=maximum(value_from_up,value_from_left,value_from_corner);
    }
   }

   int final_score=M[m][n];
   string first_final="";
   string second_final="";

   int i=m, j=n;
   while(i>0 && j>0)
   {
      bool is_matched=(first[i-1]==second[j-1]);
      if(is_matched)
      {
        first_final=first[i-1]+first_final;
        second_final=second[j-1]+second_final;
        i--;
        j--;
      }
      else
      {
        int value_up=M[i-1][j];
        int value_left=M[i][j-1];
        int value_corner=M[i-1][j-1];
        int highest=maximum(value_up, value_left, value_corner);
        if(highest==value_corner)
        {
           first_final=first[i-1]+first_final;
           second_final=second[j-1]+second_final;
           i--;
           j--;
        }
        else if(highest==value_up)
        {
           first_final=first[i-1]+first_final;
           second_final="-"+second_final;
           i--;
        }
        else if(highest==value_left)
        {
           first_final="-"+first_final;
           second_final=second[j-1]+second_final;
           j--;
        }
        
      }
   }

   while(i>0)
   {
      first_final=first[i-1]+first_final;
      second_final="-"+second_final;
      i--;
   }
   while(j>0)
   {
      first_final="-"+first_final;
      second_final=second[j-1]+second_final;
      j--;
   }

   return tuple<string, string, int>(first_final, second_final, final_score);
}



tuple<string,string,int> local_alignment(string first, string second, int gap_penalty, int mismatch_penalty, int match_score)
{
   int m=first.length();
   int n=second.length();
   int** M=new int*[m+1];
   for(int i=0; i<m+1; i++)
   {
      M[i]=new int[n+1];
   }

   for(int i=0; i<=m; i++) M[i][0]=0;
   for(int j=0; j<=n; j++) M[0][j]=0;

   for(int i=1; i<=m; i++)
   {
    for(int j=1; j<=n; j++)
    {
     int value_from_up=M[i-1][j]+gap_penalty;
     int value_from_left=M[i][j-1]+gap_penalty;
     int value_from_corner=(first[i-1]==second[j-1])? (M[i-1][j-1]+match_score):(M[i-1][j-1]+mismatch_penalty);
     if(value_from_up<0) value_from_up=0;
     if(value_from_left<0) value_from_left=0;
     if(value_from_corner<0) value_from_corner=0;
     M[i][j]=maximum(value_from_up,value_from_left,value_from_corner);
    }
   }

   int max_score, max_i,max_j;
   tie(max_score,max_i,max_j)=max_of_table(M, m+1, n+1);
   string first_aligned="";
   string second_aligned="";

   int i=max_i, j=max_j;
   while(M[i][j]>0)
   {
      bool is_matched=(first[i-1]==second[j-1]);
      if(is_matched)
      {
        first_aligned=first[i-1]+first_aligned;
        second_aligned=second[j-1]+second_aligned;
        i--;
        j--;
      }
      else
      {
        int value_up=M[i-1][j];
        int value_left=M[i][j-1];
        int value_corner=M[i-1][j-1];
        int highest=maximum(value_up, value_left, value_corner);
        if(highest==value_up)
        {
           first_aligned=first[i-1]+first_aligned;
           second_aligned="-"+second_aligned;
           i--;
        }
        else if(highest==value_left)
        {
           first_aligned="-"+first_aligned;
           second_aligned=second[j-1]+second_aligned;
           j--;
        }
        else if(highest==value_corner)
        {
           first_aligned=first[i-1]+first_aligned;
           second_aligned=second[j-1]+second_aligned;
           i--;
           j--;
        }
      }
   }
   for(int k=0; k<m+1; k++)
   {
      delete[] M[k];
   }
   delete M;
   return tuple<string, string, int>(first_aligned, second_aligned, max_score);
}




int main()
{
    string first_sequence;
    string second_sequence;

    cout<<"Enter first sequence: ";
    cin>>first_sequence;
    cout<<"Enter second sequence: ";
    cin>>second_sequence;

    int match_score;
    int mismatch_penalty;
    int gap_penalty;

    cout<<"Enter match score: ";
    cin>>match_score;
    cout<<"Enter mismatch penalty: ";
    cin>>mismatch_penalty;
    cout<<"Enter gap penalty: ";
    cin>>gap_penalty;


    string first_global;
    string second_global;
    int global_score;
    tie(first_global,second_global,global_score)=global_alignment(first_sequence, second_sequence, gap_penalty, mismatch_penalty, match_score);
    cout<<endl;
    cout<<"Global Alignment:"<<endl;
    cout<<first_global<<endl;
    cout<<second_global<<endl;
    cout<<"Maximum Score: "<<global_score<<endl;

    
    string first_local;
    string second_local;
    int local_score;
    tie(first_local,second_local,local_score)=local_alignment(first_sequence, second_sequence, gap_penalty, mismatch_penalty, match_score);
    cout<<endl;
    cout<<"Local Alignment:"<<endl;
    cout<<first_local<<endl;
    cout<<second_local<<endl;
    cout<<"Maximum Score: "<<local_score<<endl<<endl;
    return 0;
}

